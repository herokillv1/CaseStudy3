create
    definer = root@localhost procedure totalPriceBuy(OUT totalPrice int)
BEGIN

  select sum(amount_product_buy*price_product_buy)  as total into totalPrice
  from cart where id_product_buy > 0;

END;

